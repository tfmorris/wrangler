from setuptools import setup, find_packages
setup(
    name = "DataWrangler",
    version = "0.2",
    packages = find_packages(),
	url = 'http://www.stanford.edu/~skandel/platform/python/DataWrangler-0.1.tar.gz',
	download_url = 'http://www.stanford.edu/~skandel/platform/python/DataWrangler-0.1.tar.gz',
)